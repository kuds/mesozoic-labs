"""The T. rex readings test_gait_recorder.py pins or quotes, by the tests' own bodies and helpers; tree argv[1].

* test_the_physics_r9_statue_whole_foot_cop_reading: seed 3042, 1000 zero steps, episode_pad_telemetry(settle 200).
* test_each_statue_stands_on_its_registered_support_geoms (T. rex): seed 3042, 1 s + 150 steps, max_sole_cop_fore_aft.
* test_the_whole_foot_cop_is_its_definition...: statue (jitter 0), 300 steps, max/median |foot_cop - moment| after
  step 100, and the largest sole tilt after step 100 is not read here (comment only).
* test_each_hinged_digits_load_position...: 200 steps, median hinged-digit load position after step 100.
"""

import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from environments.shared.gait.morphology import Morphology  # noqa: E402
from environments.shared.gait.pad_telemetry import PadLayout, episode_pad_telemetry  # noqa: E402
from environments.shared.gait.recorder import SubstepContactRecorder  # noqa: E402
from environments.shared.gait.stance_metrics import episode_stance_metrics  # noqa: E402
from environments.shared.tests import test_gait_recorder as T  # noqa: E402

built = []


def envs(model_id, **overrides):
    env = T.make_env(model_id, **overrides)
    built.append(env)
    return env


out: dict = {"tree": str(ROOT)}
TR = T.TYRANNOSAURUS_REX

env = envs(TR)
morphology = Morphology.from_env(env, TR)
zero = np.zeros(env.model.nu)
with SubstepContactRecorder(env, morphology) as recorder:
    env.reset(seed=3042)
    for _ in range(1000):
        env.step(zero)
        recorder.end_step(zero, 0.0)
    trace = recorder.end_episode(truncated=True)
pads = episode_pad_telemetry(trace, PadLayout.from_morphology(morphology), settle_steps=200)
out["golden"] = {
    "r_foot_cop_fore_aft_gate": float(pads["r_foot_cop_fore_aft_gate"]),
    "l_foot_cop_fore_aft_gate": float(pads["l_foot_cop_fore_aft_gate"]),
    "r_foot_cop_fore_aft": float(pads["r_foot_cop_fore_aft"]),
    "l_foot_cop_fore_aft": float(pads["l_foot_cop_fore_aft"]),
    "mean_foot_cop_right_200_999": float(np.mean(trace.foot_cop[200:, 0])),
    "mean_foot_cop_left_200_999": float(np.mean(trace.foot_cop[200:, 1])),
    "max_foot_cop_fore_aft_metric": float(episode_stance_metrics(trace, settle_steps=200).max_foot_cop_fore_aft),
}
out["golden_repr"] = {k: repr(v) for k, v in out["golden"].items()}

env = envs(TR)
settle = int(round(1.0 / env.dt))
with SubstepContactRecorder(env, Morphology.from_env(env, TR)) as recorder:
    env.reset(seed=3042)
    for _ in range(settle + 150):
        env.step(zero)
        recorder.end_step(zero, 0.0)
    trace = recorder.end_episode(truncated=True)
out["ceiling_test_max_sole_cop_fore_aft"] = float(episode_stance_metrics(trace, settle_steps=settle).max_sole_cop_fore_aft)

trace, probe, _ = T._whole_foot_rollout(envs, 300, jitter=0.0)
difference = np.abs(trace.foot_cop - np.array(probe.moment_over_force))
d = difference[100:]
out["statue_moment_difference_after_100_max_m"] = float(np.nanmax(d))
out["statue_moment_difference_after_100_median_m"] = float(np.nanmedian(d))
out["statue_mean_foot_cop_after_100"] = float(np.nanmean(trace.foot_cop[100:]))

trace, probe, morphology = T._whole_foot_rollout(envs, 200)
hinged = [support for support, joint in enumerate(morphology.support_geom_mtp) if joint >= 0]
loads = trace.support_load_pos[100:, hinged]
out["digit_load_pos_median_after_100"] = float(np.nanmedian(loads))
out["digit_load_pos_per_digit_median_after_100"] = [float(np.nanmedian(loads[:, k])) for k in range(loads.shape[1])]

for env in built:
    env.close()
print(json.dumps(out, indent=1))
