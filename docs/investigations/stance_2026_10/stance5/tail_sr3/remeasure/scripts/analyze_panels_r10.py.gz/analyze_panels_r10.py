"""Summarise the 280-seed 0-deg-cell panels and the six-heading certificates for both trees into JSON + CSV."""
import csv, json, math, sys
from pathlib import Path
G = Path(sys.argv[1])
BLOCKS = [(3042, 40), (3082, 80), (3162, 40), (5042, 40), (7042, 40), (9042, 40)]
BARS = [  # (metric, direction, threshold key)
    ("max_sole_tilt_deg", "max", "max_sole_tilt_deg"), ("max_sole_corner_lift_m", "max", "max_sole_corner_lift_m"),
    ("min_sole_contacts", "min", "min_sole_contacts"), ("max_sole_cop_fore_aft", "max", "max_sole_cop_fore_aft"),
    ("settle_peak_floor_force_bw", "max", "max_settle_peak_floor_force_bw"),
    ("min_foot_load_share_windowed", "min", "min_foot_load_share_windowed"), ("min_foot_load_share", "min", "min_foot_load_share"),
    ("window_displacement_m", "max", "max_window_displacement_m"), ("settle_stance_width_change_m", "max", "max_settle_stance_width_change_m"),
    ("episode_yaw_change_deg", "max", "max_episode_yaw_change_deg"), ("all_feet_support", "min", "min_all_feet_support"),
    ("touchdown_rate", "max", "max_touchdown_rate"), ("max_actuator_saturation_fraction", "max", "max_actuator_saturation_fraction"),
    ("settle_airborne_substeps", "max", "max_settle_airborne_substeps"), ("settle_touchdowns", "max", "max_settle_touchdowns"),
    ("foot_on_foot_fraction", "max", "max_foot_contact_fraction"), ("phantom_support_fraction", "max", "max_phantom_support_fraction"),
    ("nonfoot_load_fraction", "max", "max_nonfoot_load_fraction"),
]

def extreme(rows, metric, direction):
    vals = [(r[metric], r["seed"]) for r in rows if r.get(metric) is not None and isinstance(r[metric], (int, float)) and math.isfinite(r[metric])]
    if not vals:
        return None
    v = max(vals) if direction == "max" else min(vals)
    return {"value": v[0], "seed": v[1]}

summary = {}
csv_rows = []
for tree in ("r10",):
    s = {"blocks": [], "all": {}}
    allrows, allfull = [], []
    rewards_full = []
    terms = {}
    for seed, n in BLOCKS:
        p = G / "panels" / tree / f"v2cell0_{seed}_{n}.json"
        if not p.exists():
            s["blocks"].append({"seed": seed, "n": n, "missing": True}); continue
        d = json.loads(p.read_text())
        rows = d["episode_evidence"]; th = d["thresholds"]
        full = [r for r in rows if r["reached_horizon"]]
        unclean = [{"seed": r["seed"], "length": r["length"], "reasons": [x.split(":")[0] for x in r["reasons"]],
                    "reasons_full": r["reasons"]} for r in rows if not r["clean"]]
        for k, v in d["terminations"].items():
            terms[k] = terms.get(k, 0) + v
        b = {"seed": seed, "n": n, "n_clean": d["result"]["n_clean"], "clean_lcb": d["result"]["clean_lcb"],
             "n_full_horizon": d["result"]["n_full_horizon"], "passed_v2_decision": d["passed"], "failures": d["failures"],
             "hop_or_fall_episodes": d["result"].get("hop_or_fall_episodes"),
             "reward_mean": d["metrics"]["reward_mean"], "reward_std": d["metrics"]["reward_std"],
             "statue_reference": d["statue"]["reference"], "terminations": d["terminations"], "unclean": unclean,
             "seconds": d["_driver"]["seconds"],
             "extremes_full_horizon": {m: extreme(full, m, dr) for m, dr, _ in BARS}}
        s["blocks"].append(b)
        allrows += rows; allfull += full; rewards_full += [r["reward"] for r in full]
        for r in rows:
            csv_rows.append({"tree": tree, "block": seed, **{k: r.get(k) for k in ("seed", "length", "reached_horizon", "clean", "reward",
                             "max_sole_tilt_deg", "max_sole_corner_lift_m", "min_sole_contacts", "max_sole_cop_fore_aft",
                             "max_foot_cop_fore_aft", "settle_peak_floor_force_bw", "min_foot_load_share_windowed", "min_foot_load_share",
                             "window_displacement_m", "settle_stance_width_change_m", "episode_yaw_change_deg", "mean_sole_pitch_deg")},
                             "reasons": "|".join(x.split(":")[0] for x in r.get("reasons", []))})
    if allrows:
        import statistics as st
        s["all"] = {"n": len(allrows), "n_clean": sum(r["clean"] for r in allrows), "n_full_horizon": len(allfull),
                    "terminations": terms,
                    "standing_reward_mean": st.fmean(rewards_full), "standing_reward_sd": st.pstdev(rewards_full),
                    "unclean_seeds": [(r["seed"], r["length"], sorted({x.split(':')[0] for x in r["reasons"]})) for r in allrows if not r["clean"]],
                    "extremes_full_horizon": {m: extreme(allfull, m, dr) for m, dr, _ in BARS},
                    "extremes_full_horizon_out_of_sample": {m: extreme([r for r in allfull if not 3042 <= r["seed"] <= 3081], m, dr) for m, dr, _ in BARS},
                    "median_min_sole_contacts": st.median([r["min_sole_contacts"] for r in allfull]),
                    "median_max_sole_cop_fore_aft": st.median([r["max_sole_cop_fore_aft"] for r in allfull]),
                    "mean_max_sole_cop_fore_aft": st.fmean([r["max_sole_cop_fore_aft"] for r in allfull])}
    # six-heading certificate
    hp = G / "panels" / tree / "heading_cert" / "stance_heading_report.json"
    if hp.exists():
        h = json.loads(hp.read_text())
        s["heading_certificate"] = {
            "passed": h["passed"], "failures": h["failures"], "seeds": [h["seeds"][0], h["seeds"][-1]],
            "result_top": {k: v for k, v in h["result"].items() if not isinstance(v, (list, dict))},
            "headings": [{"yaw_deg": c["yaw_deg"], "n_clean": c["metrics"]["n_clean"], "clean_lcb": c["metrics"]["clean_lcb"],
                          "full_horizon_fraction": c["metrics"]["full_horizon_fraction"], "reward_mean": c["metrics"]["reward_mean"],
                          "reward_std": c["metrics"]["reward_std"], "terminations": c["terminations"],
                          "statue_reference": (c["statue"] or {}).get("reference"),
                          "passed": (c["result"] or {}).get("passed"), "failures": (c["result"] or {}).get("failures"),
                          "unclean": [(r["seed"], r["length"], sorted({x.split(':')[0] for x in r["reasons"]})) for r in c["episode_evidence"] if not r["clean"]],
                          "max_sole_cop_fore_aft_full": extreme([r for r in c["episode_evidence"] if r["reached_horizon"]], "max_sole_cop_fore_aft", "max")}
                         for c in h["headings"]],
            "task_sha256": h["task_sha256"], "gate_sha256": h["gate_sha256"],
            "plant_physics_revision": h["plant_identity"].get("physics_revision") if isinstance(h["plant_identity"], dict) else None,
        }
        # bit-identity of heading cells against the 0-deg cell, per seed (rewards and CoP)
        cells = {c["yaw_deg"]: {r["seed"]: r for r in c["episode_evidence"]} for c in h["headings"]}
        zero = cells.get(0.0) or cells.get(0)
        diffs = {}
        for yaw, rows in cells.items():
            diffs[str(yaw)] = max(abs(rows[sd]["reward"] - zero[sd]["reward"]) for sd in zero)
        s["heading_certificate"]["max_abs_reward_diff_vs_0deg"] = diffs
        # the certificate's 0-deg cell vs this driver's v2 panel on 3042-3081
        p = G / "panels" / tree / "v2cell0_3042_40.json"
        if p.exists():
            v2 = {r["seed"]: r for r in json.loads(p.read_text())["episode_evidence"]}
            s["heading_certificate"]["cell0_vs_v2_driver_max_abs_reward_diff"] = max(abs(v2[sd]["reward"] - zero[sd]["reward"]) for sd in zero)
            s["heading_certificate"]["cell0_vs_v2_driver_same_clean_flags"] = all(v2[sd]["clean"] == zero[sd]["clean"] for sd in zero)
    summary[tree] = s
(G / "panels_summary.json").write_text(json.dumps(summary, indent=1, default=float))
with open(G / "panels_episodes.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(csv_rows[0].keys())); w.writeheader(); w.writerows(csv_rows)
for tree, s in summary.items():
    print(tree, json.dumps(s.get("all", {}).get("unclean_seeds")), s.get("all", {}).get("n_clean"), "/", s.get("all", {}).get("n"))
