"""recovery_offdist_panel's statue/on/provisional panel through its own build_env/roll_panel, with env.step wrapped
to record each episode's termination reason (the harness JSON has none).  Tree argv[1]; output JSON argv[2]."""
import collections
import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from environments.shared.harnesses import recovery_offdist_panel as H  # noqa: E402

env = H.build_env("on", model_id=H.SCHEDULE_MODEL_ID)
reasons = []
inner = env.step


def step(action):
    out = inner(action)
    if out[2]:
        reasons.append(out[4].get("termination_reason"))
    elif out[3]:
        reasons.append("truncated")
    return out


env.step = step
predict = H.zero_action_controller(env.action_space.shape[0])
result = H.roll_panel(env, predict, controller_id="statue/on/provisional", safe_set=dict(H.DEFAULT_SAFE_SET),
                      height_reference=None)
rewards = np.array([e["reward"] for e in result["per_episode"]])
for e, r in zip(result["per_episode"], reasons):
    e["end"] = r
summary = {k: v for k, v in result.items() if k != "per_episode"}
summary["std_reward_ddof1"] = float(rewards.std(ddof=1))
summary["standard_error"] = float(rewards.std(ddof=1) / np.sqrt(len(rewards)))
summary["ends"] = dict(collections.Counter(reasons))
summary["tree"] = str(ROOT)
result.update(summary)
Path(sys.argv[2]).write_text(json.dumps(result, indent=1))
print(json.dumps(summary, indent=1))
