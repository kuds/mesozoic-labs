"""Replicate test_stance_gate_v2_report.py::TestThePadCentreOfPressure (T. rex) with the test module's own
helpers, and sweep the left-ankle lean command, recording every episode row and the statue rows.

usage: cop_probe.py TREE OUTJSON WORKDIR CMD [CMD ...]
"""
import json, sys
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(ROOT))
OUT = Path(sys.argv[2]); WORK = Path(sys.argv[3]); WORK.mkdir(parents=True, exist_ok=True)
import numpy as np
from environments.shared.tests import test_stance_gate_v2_report as T
from environments.shared.species_registry import env_class as model_env_class

class _MP:
    def setattr(self, obj, name, value):
        setattr(obj, name, value)

KEYS = ("length", "all_feet_support", "max_sole_cop_fore_aft", "max_sole_corner_lift_m", "max_sole_tilt_deg",
        "min_sole_contacts", "max_foot_cop_fore_aft")
results = {"tree": str(ROOT), "horizon": T.TYRANNOSAURUS_REX_HORIZON, "episodes": T.EPISODES, "runs": []}
for cmd in (float(x) for x in sys.argv[4:]):
    config = T._tyrannosaurus_rex_stage_config()
    curriculum = config["curriculum_kwargs"]
    d = WORK / f"cmd_{cmd:+.4f}"; d.mkdir(parents=True, exist_ok=True)
    T._record_stage(d, config, model_id=T.TYRANNOSAURUS_REX)
    env = model_env_class(T.TYRANNOSAURUS_REX)(**config["env_kwargs"])
    try:
        command = np.zeros(int(env.action_space.shape[0]))
        command[env.model.actuator("l_ankle_act").id] = cmd
    finally:
        env.close()
    predict = T._ramped(command, steps=300, horizon=T.TYRANNOSAURUS_REX_HORIZON)
    rep = T._report(_MP(), d, predict, model_id=T.TYRANNOSAURUS_REX, stage_config=config)
    rows = [{k: r.get(k) for k in ("seed", "clean", "reasons") + KEYS} for r in rep["episode_evidence"]]
    srows = [{k: r.get(k) for k in ("seed",) + KEYS} for r in rep["statue"]["episode_evidence"]]
    run = {"l_ankle_cmd": cmd, "n_clean": rep["result"]["n_clean"], "passed": rep["passed"], "rows": rows, "statue_rows": srows,
           "bar_max_sole_cop_fore_aft": curriculum["max_sole_cop_fore_aft"],
           "bar_max_sole_corner_lift_m": curriculum.get("max_sole_corner_lift_m"),
           "bar_max_sole_tilt_deg": curriculum.get("max_sole_tilt_deg"),
           "bar_min_sole_contacts": curriculum.get("min_sole_contacts"),
           "fixture_asserts": {
               "n_clean_0": rep["result"]["n_clean"] == 0,
               "all_rows_cop_gt_0.82": all(r["max_sole_cop_fore_aft"] > 0.82 for r in rows),
               "only_cop_bar_fails": all({x.split(":")[0] for x in r["reasons"]} == {"max_sole_cop_fore_aft"} for r in rows),
               "statue_rows_under_bar": all(r["max_sole_cop_fore_aft"] < curriculum["max_sole_cop_fore_aft"] for r in srows)}}
    results["runs"].append(run)
    print(f"cmd {cmd:+.4f}: n_clean {run['n_clean']} cop {[round(r['max_sole_cop_fore_aft'],4) for r in rows]} "
          f"lift_mm {[round(1e3*r['max_sole_corner_lift_m'],2) for r in rows]} tilt {[round(r['max_sole_tilt_deg'],3) for r in rows]} "
          f"contacts {[round(r['min_sole_contacts'],2) for r in rows]} reasons {[sorted({x.split(':')[0] for x in r['reasons']}) for r in rows]} "
          f"statue_cop {[round(r['max_sole_cop_fore_aft'],4) for r in srows]} asserts {run['fixture_asserts']}", flush=True)
OUT.write_text(json.dumps(results, indent=1, default=float))
