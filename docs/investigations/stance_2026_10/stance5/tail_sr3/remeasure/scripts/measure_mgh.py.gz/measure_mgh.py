"""m.g.h of the settled statue by test_hip_roll_servos_out_stiffen_the_lateral_gravity_moment's own procedure.

The test's env fixture (reset_noise_scale=0.0, nosedive_termination_threshold=0.35, reset(seed=0)), 600 zero-action
steps, body_subtreemass[pelvis] x 9.81 x _clearance(subtree_com[pelvis]); tree argv[1].
"""

import json
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))

import mujoco  # noqa: E402
import numpy as np  # noqa: E402

from environments.tyrannosaurus_rex.anatomical.env import TyrannosaurusRexAnatomicalEnv as Env  # noqa: E402

env = Env(reset_noise_scale=0.0, nosedive_termination_threshold=0.35)
env.reset(seed=0)
try:
    a = np.zeros(env.action_space.shape, dtype=np.float32)
    for _ in range(600):
        env.step(a)
    m = env.model
    mass = float(m.body_subtreemass[env.pelvis_id])
    h = float(env._clearance(env.data.subtree_com[env.pelvis_id]))
    g = mass * -float(m.opt.gravity[2]) * h
    s = []
    for side in ("r", "l"):
        aid = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_ACTUATOR, f"{side}_hip_roll_act")
        jid = mujoco.mj_name2id(m, mujoco.mjtObj.mjOBJ_JOINT, f"{side}_hip_roll")
        s.append(float(m.actuator_gainprm[aid, 0] + m.jnt_stiffness[jid]))
    print(json.dumps({"tree": str(ROOT), "subtree_mass": mass, "com_height_m": h, "mgh": g, "servo_sum": sum(s),
                      "ratio": sum(s) / g}, indent=1))
finally:
    env.close()
