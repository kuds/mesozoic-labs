"""_LEG_SETTLED_QPOS by its documented procedure, in tree argv[1].

The stance config's env_kwargs, zero action, seeds 3042-3051 (all ten must be full horizon), mean over steps
200-999 per seed, mean of seeds, mirror-symmetrised as test_the_settled_leg_pose_is_the_statues does (pairs
averaged, hip roll sign-mapped [1, -1, 1, 1]).  Also: the raw-pair agreement, the deviations from the keyframe in
degrees, the 200-399 window the test uses, and the noise-free statue's leg pose (hip roll).
"""

import json
import math
import sys
import time
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from environments.shared.config import load_stage_config  # noqa: E402
from environments.shared.model_id import ModelId  # noqa: E402
from environments.tyrannosaurus_rex.anatomical.env import TyrannosaurusRexAnatomicalEnv as Env  # noqa: E402

SIGN = np.array([1.0, -1.0, 1.0, 1.0])


def symmetrise(mean):
    half = (mean[:4] + SIGN * mean[4:]) / 2
    return np.concatenate([half, SIGN * half])


out: dict = {"tree": str(ROOT), "utc_start": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
kw = dict(load_stage_config(ModelId("tyrannosaurus_rex", "anatomical"), "stance")["env_kwargs"])
env = Env(**kw)
try:
    means_999, means_399, full = [], [], []
    for seed in range(3042, 3052):
        env.reset(seed=seed)
        w999, w399 = [], []
        ended = None
        for step in range(1000):
            _, _, term, trunc, info = env.step(np.zeros(15, dtype=np.float32))
            q = env.data.qpos[env._leg_home_qpos_indices].copy()
            if step >= 200:
                w999.append(q)
                if step < 400:
                    w399.append(q)
            if term:
                ended = (step, info.get("termination_reason"))
                break
        full.append(ended is None)
        means_999.append(np.mean(w999, 0))
        means_399.append(np.mean(w399, 0))
    out["full_horizon"] = full
    m999 = np.mean(means_999, 0)
    m399 = np.mean(means_399, 0)
    sym999 = symmetrise(m999)
    sym399 = symmetrise(m399)
    out["raw_mean_200_999"] = m999.tolist()
    out["raw_pair_disagreement_200_999"] = (m999[:4] - SIGN * m999[4:]).tolist()
    out["raw_pair_max_abs_disagreement_200_999"] = float(np.max(np.abs(m999[:4] - SIGN * m999[4:])))
    out["symmetrised_200_999"] = sym999.tolist()
    out["symmetrised_200_999_repr"] = [repr(float(v)) for v in sym999]
    out["symmetrised_200_399"] = sym399.tolist()
    out["test_window_minus_constant_candidate_max_abs"] = float(np.max(np.abs(sym399 - sym999)))
    out["LEG_SETTLED_QPOS_in_tree"] = list(Env._LEG_SETTLED_QPOS)
    out["in_tree_constant_minus_measured_max_abs"] = float(np.max(np.abs(np.array(Env._LEG_SETTLED_QPOS) - sym999)))
    keyframe = env.model.key_qpos[env.home_keyframe_id][env._leg_home_qpos_indices]
    out["keyframe"] = keyframe.tolist()
    out["deviation_from_keyframe_deg"] = np.degrees(sym999 - keyframe).tolist()
    out["max_abs_deviation_from_keyframe_deg"] = float(np.degrees(np.max(np.abs(sym999 - keyframe))))
finally:
    env.close()

env = Env(**{**kw, "reset_noise_scale": 0.0})
try:
    env.reset(seed=0)
    w = []
    for step in range(1000):
        _, _, term, _, _ = env.step(np.zeros(15, dtype=np.float32))
        assert not term
        if step >= 200:
            w.append(env.data.qpos[env._leg_home_qpos_indices].copy())
    nf = np.mean(w, 0)
    out["noise_free_200_999"] = nf.tolist()
    out["noise_free_hip_roll_deg"] = [math.degrees(nf[1]), math.degrees(nf[5])]
    out["noise_free_minus_symmetrised_deg"] = np.degrees(nf - sym999).tolist()
    out["noise_free_minus_symmetrised_max_abs_deg_excluding_hip_roll"] = float(
        np.degrees(np.max(np.abs((nf - sym999)[[0, 2, 3, 4, 6, 7]])))
    )
finally:
    env.close()
out["utc_end"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
print(json.dumps(out, indent=1))
