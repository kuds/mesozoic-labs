"""The gate's statue (zero action) on seed blocks, through the repo's own report code.

The stance stage declares stance_quality_heading/v1, whose certificate is build_stance_heading_report
(six whole-scene headings).  Each heading cell is the stance_quality/v2 decision; at 0 deg the turn is
the identity and the cell is the v2 panel bit for bit (the function's docstring).  This driver scores
the 0-deg cell on arbitrary seed blocks by calling build_stance_gate_report on the committed stage
config with ONLY curriculum.gate_kind set to "stance_quality/v2" (every bar, rail and the env block
unchanged), i.e. _stance_v2_report: run_panel(floor_truth=True), statue_reference, evaluate_stance_v2_gate.

usage: statue_v2_blocks.py TREE OUTDIR SEED:N [SEED:N ...]
"""
import copy, json, sys, time
from pathlib import Path
ROOT = Path(sys.argv[1]).resolve(); sys.path.insert(0, str(ROOT))
OUT = Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
from environments.shared.config import load_stage_config
from environments.shared.model_id import ModelId
from environments.shared.reporting.stance_report import build_stance_gate_report, _json_safe

mid = ModelId("tyrannosaurus_rex", "anatomical")
cfg = load_stage_config(mid, 1)
assert cfg["curriculum_kwargs"]["gate_kind"] == "stance_quality_heading/v1", cfg["curriculum_kwargs"]["gate_kind"]
v2cfg = copy.deepcopy(cfg)
v2cfg["curriculum_kwargs"]["gate_kind"] = "stance_quality/v2"
for spec in sys.argv[3:]:
    seed, n = (int(x) for x in spec.split(":"))
    t0 = time.time()
    rep = build_stance_gate_report(mid, 1, stage_config=v2cfg, zero_action=True, episodes=n, seed=seed)
    dt = time.time() - t0
    rep["_driver"] = {"tree": str(ROOT), "seconds": dt, "note": "gate_kind swapped to stance_quality/v2 for the 0-deg cell; all else committed"}
    (OUT / f"v2cell0_{seed}_{n}.json").write_text(json.dumps(_json_safe(rep), indent=1))
    m = rep["metrics"]; st = rep["statue"]["reference"]
    print(f"block {seed}+{n}: clean {m['n_clean']}/{n} lcb {m['clean_lcb']:.3f} full_horizon {m['full_horizon_fraction']:.3f} "
          f"reward_mean {m['reward_mean']:.2f} statue_ref_mean_reward {st['mean_reward']:.2f} n_full {st['n_full_horizon']} "
          f"passed {rep['passed']} failures {rep['failures']} [{dt:.1f}s]", flush=True)
