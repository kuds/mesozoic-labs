"""Settle constants of the T. rex statue in a given tree (argv[1]), each by the repo's own procedure.

* neck / tail targets: TestSettledPoseTargetsTrackTheStatue._post_settle_means (the test's own helper:
  TyrannosaurusRexAnatomicalEnv(reset_noise_scale=0.0), reset(seed=0), 1000 zero-action steps, mean of steps 200-999).
* natural_pitch: the same noise-free roll, mean info["forward_z"] (and pelvis xmat[6]) over steps 200-999,
  natural_pitch = asin(-forward_z) (plant_versions note 16 / commit 5a93c429 method).
* pelvis z over 200-999 and at step 600 (target_z comment: zero action, zero reset noise, 600 steps).
* head tip z, stance width, the noise-free 1000-step reward of the default env and of the stance config at noise 0.
* 40-seed spread: the stance config (reset noise 0.05), seeds 3042-3081, steps 200-999: per-seed neck/tail means,
  their mean and sd (full-horizon count).
* long-run neck/tail: noise-free, max_episode_steps 5000, mean of steps 4000-4999 (method stated, not the repo's).
"""

import json
import math
import sys
import time
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(ROOT))

import numpy as np  # noqa: E402

from environments.shared.config import load_stage_config  # noqa: E402
from environments.shared.model_id import ModelId  # noqa: E402
from environments.tyrannosaurus_rex.anatomical.env import TyrannosaurusRexAnatomicalEnv as Env  # noqa: E402
from environments.tyrannosaurus_rex.tests.test_anatomical_env import TestSettledPoseTargetsTrackTheStatue  # noqa: E402

out: dict = {"tree": str(ROOT), "utc_start": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}

# 1. The test's own helper.
neck, tail = TestSettledPoseTargetsTrackTheStatue._post_settle_means()
out["test_helper_neck_post_settle_mean"] = neck.tolist()
out["test_helper_tail_post_settle_mean"] = tail.tolist()
out["NECK_SETTLED_QPOS_in_tree"] = list(Env._NECK_SETTLED_QPOS)
out["TAIL_SETTLED_QPOS_in_tree"] = list(Env._TAIL_SETTLED_QPOS)

# 2. The same noise-free roll with the other readings.
env = Env(reset_noise_scale=0.0)
try:
    env.reset(seed=0)
    a = np.zeros(env.model.nu, dtype=np.float32)
    fz, xm6, z, head, width, rewards = [], [], [], [], [], []
    z600 = None
    for step in range(1000):
        _, r, term, trunc, info = env.step(a)
        assert not term, step
        rewards.append(float(r))
        if step == 599:
            z600 = float(env.data.xpos[env.pelvis_id, 2])
        if step >= 200:
            fz.append(float(info["forward_z"]))
            xm6.append(float(env.data.xmat[env.pelvis_id, 6]))
            z.append(float(env.data.xpos[env.pelvis_id, 2]))
            head.append(float(info["head_tip_z"]))
            width.append(float(info["stance_width"]))
    mfz = float(np.mean(fz))
    out["forward_z_mean_200_999"] = mfz
    out["pelvis_xmat6_mean_200_999"] = float(np.mean(xm6))
    out["natural_pitch_measured_rad"] = math.asin(-mfz)
    out["natural_pitch_measured_deg"] = math.degrees(math.asin(-mfz))
    out["pelvis_z_mean_200_999"] = float(np.mean(z))
    out["pelvis_z_sd_200_999"] = float(np.std(z))
    out["pelvis_z_step600"] = z600
    out["head_tip_z_mean_200_999"] = float(np.mean(head))
    out["stance_width_mean_200_999"] = float(np.mean(width))
    out["default_env_noise_free_1000_step_reward"] = float(np.sum(rewards))
finally:
    env.close()

# 3. Noise-free stance-config reward.
kw = dict(load_stage_config(ModelId("tyrannosaurus_rex", "anatomical"), "stance")["env_kwargs"])
env = Env(**{**kw, "reset_noise_scale": 0.0})
try:
    env.reset(seed=0)
    total, steps = 0.0, 0
    for step in range(1000):
        _, r, term, trunc, info = env.step(np.zeros(env.model.nu, dtype=np.float32))
        total += float(r)
        steps += 1
        if term or trunc:
            break
    out["stance_config_noise_free_reward"] = total
    out["stance_config_noise_free_steps"] = steps
finally:
    env.close()

# 4. 40-seed spread at the stance config's reset noise 0.05.
env = Env(**kw)
try:
    per_seed_neck, per_seed_tail, full = [], [], 0
    for seed in range(3042, 3082):
        env.reset(seed=seed)
        n, t = [], []
        ended = False
        for step in range(1000):
            _, _, term, trunc, _ = env.step(np.zeros(env.model.nu, dtype=np.float32))
            if step >= 200:
                n.append(env.data.qpos[env._neck_home_qpos_indices].copy())
                t.append(env.data.qpos[env._tail_home_qpos_indices].copy())
            if term:
                ended = True
                break
        full += 0 if ended else 1
        if n:
            per_seed_neck.append(np.mean(n, 0))
            per_seed_tail.append(np.mean(t, 0))
    out["spread40_config"] = "stance env_kwargs (reset_noise_scale 0.05), seeds 3042-3081, steps 200-999"
    out["spread40_full_horizon"] = full
    out["spread40_neck_mean"] = np.mean(per_seed_neck, 0).tolist()
    out["spread40_neck_sd"] = np.std(per_seed_neck, 0, ddof=1).tolist()
    out["spread40_tail_mean"] = np.mean(per_seed_tail, 0).tolist()
    out["spread40_tail_sd"] = np.std(per_seed_tail, 0, ddof=1).tolist()
    out["spread40_tail_max_abs_dev_from_noise_free"] = float(np.max(np.abs(np.array(per_seed_tail) - tail)))
    out["spread40_neck_max_abs_dev_from_noise_free"] = float(np.max(np.abs(np.array(per_seed_neck) - neck)))
finally:
    env.close()

# 5. Long-run equilibrium (stated method).
env = Env(reset_noise_scale=0.0, max_episode_steps=5000)
try:
    env.reset(seed=0)
    n, t = [], []
    for step in range(5000):
        _, _, term, _, _ = env.step(np.zeros(env.model.nu, dtype=np.float32))
        assert not term, step
        if step >= 4000:
            n.append(env.data.qpos[env._neck_home_qpos_indices].copy())
            t.append(env.data.qpos[env._tail_home_qpos_indices].copy())
    out["long_run_method"] = "noise-free, seed 0, max_episode_steps 5000, mean of steps 4000-4999"
    out["long_run_neck"] = np.mean(n, 0).tolist()
    out["long_run_tail"] = np.mean(t, 0).tolist()
finally:
    env.close()

out["utc_end"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
print(json.dumps(out, indent=1))
